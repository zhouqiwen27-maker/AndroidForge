package com.qingping.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock

class ClearScreenAccessibilityService : AccessibilityService() {
    private val prefs by lazy { getSharedPreferences("qingping_stats", MODE_PRIVATE) }

    private val explicitCloseWords = listOf("跳过广告", "关闭广告", "skip ad", "close ad")
    private val adClickWords = listOf("广告", "立即下载", "立即打开", "打开应用", "install", "open app", "download")

    private var lastClickPackage: String? = null
    private var lastClickLabel = ""
    private var lastClickTime = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return

        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            lastClickLabel = buildString {
                append(event.text.joinToString(" "))
                event.contentDescription?.let { append(" $it") }
            }.lowercase()
            lastClickPackage = pkg
            lastClickTime = SystemClock.elapsedRealtime()
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val root = rootInActiveWindow
            if (root != null) {
                try {
                    if (tryClickCloseButton(root, pkg)) return
                } finally {
                    root.recycle()
                }
            }
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val age = SystemClock.elapsedRealtime() - lastClickTime
            val sourcePkg = lastClickPackage
            val likelyAdClick = adClickWords.any { lastClickLabel.contains(it) }
            if (sourcePkg != null && sourcePkg != pkg && age in 0..2000 && likelyAdClick) {
                increment(sourcePkg, "redirect_candidate")
                lastClickTime = 0L
                lastClickPackage = null
                lastClickLabel = ""
            }
        }
    }

    private fun tryClickCloseButton(root: AccessibilityNodeInfo, pkg: String): Boolean {
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        collectNodes(root, nodes, 0)
        try {
            for (node in nodes) {
                val label = listOfNotNull(
                    node.text?.toString(),
                    node.contentDescription?.toString()
                ).joinToString(" ").lowercase()
                val explicitClose = explicitCloseWords.any { label.contains(it) }
                if (explicitClose && node.isClickable && node.isEnabled) {
                    if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        increment(pkg, "close_attempt")
                        return true
                    }
                }
            }
        } finally {
            nodes.forEach { it.recycle() }
        }
        return false
    }

    private fun collectNodes(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 15 || out.size >= 300) return
        out.add(AccessibilityNodeInfo.obtain(node))
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                collectNodes(child, out, depth + 1)
            } finally {
                child.recycle()
            }
        }
    }

    private fun increment(pkg: String, type: String) {
        val key = "$type:$pkg"
        prefs.edit()
            .putInt(key, prefs.getInt(key, 0) + 1)
            .putLong("last_event_time", System.currentTimeMillis())
            .apply()
    }

    override fun onInterrupt() = Unit
}
