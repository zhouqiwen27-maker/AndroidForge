package com.qingping.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("qingping_stats", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
    }

    override fun onResume() {
        super.onResume()
        showDashboard()
    }

    private fun showDashboard() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 28)
        }

        layout.addView(TextView(this).apply {
            text = "清屏"
            textSize = 32f
            setTextColor(0xFF172033.toInt())
        })
        layout.addView(TextView(this).apply {
            text = "广告辅助工具 · 本地统计"
            textSize = 15f
            setPadding(0, 8, 0, 24)
        })
        layout.addView(Button(this).apply {
            text = "开启 / 管理无障碍防护"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        layout.addView(Button(this).apply {
            text = "刷新统计"
            setOnClickListener { showDashboard() }
        })

        val all = prefs.all
        val packages = all.keys
            .filter { it.startsWith("close_attempt:") || it.startsWith("redirect_candidate:") }
            .map { it.substringAfter(":") }
            .distinct()
            .sorted()

        val closeTotal = all.filterKeys { it.startsWith("close_attempt:") }
            .values.sumOf { (it as? Int) ?: 0 }
        val redirectTotal = all.filterKeys { it.startsWith("redirect_candidate:") }
            .values.sumOf { (it as? Int) ?: 0 }

        val report = StringBuilder()
        report.append("关闭按钮点击尝试：$closeTotal\n")
        report.append("疑似跳转事件：$redirectTotal\n\n")
        report.append("按应用统计\n\n")
        if (packages.isEmpty()) {
            report.append("暂无记录。请先开启无障碍防护，再使用其他 APP。")
        } else {
            packages.forEach { pkg ->
                report.append("$pkg\n")
                report.append("  关闭尝试：${prefs.getInt("close_attempt:$pkg", 0)}\n")
                report.append("  疑似跳转：${prefs.getInt("redirect_candidate:$pkg", 0)}\n\n")
            }
        }
        layout.addView(TextView(this).apply {
            text = report.toString()
            textSize = 16f
            setPadding(0, 20, 0, 24)
        })

        val scroll = ScrollView(this).apply { addView(layout) }
        setContentView(scroll)
    }
}
