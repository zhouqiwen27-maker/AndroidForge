package com.qingping.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        // Android 不允许普通应用在所有版本上无条件恢复无障碍或启动后台服务。
        // 此接收器仅保留开机事件入口；实际防护依赖用户此前启用的系统无障碍服务。
        val prefs = context.getSharedPreferences("qingping_stats", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("boot_seen", true).apply()
    }
}
